class Answer < ActiveRecord::Base

end
