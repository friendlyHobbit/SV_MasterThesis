(
function(e)
{
	function t(t)
	{
		for(var o,i,c=t[0],l=t[1],a=t[2],h=0,d=[];h<c.length;h++)
		i=c[h],s[i]&&d.push(s[i][0]),s[i]=0;
		for(o in l)
			Object.prototype.hasOwnProperty.call(l,o)&&(e[o]=l[o]);u&&u(t);
		while(d.length)
			d.shift()();
			return n.push.apply(n,a||[]),r()
			}
			function r()
			{
				for(var e,t=0;t<n.length;t++)
				{
					for(var r=n[t],o=!0,c=1;c<r.length;c++)
					{
						var l=r[c];0!==s[l]&&(o=!1)
					}
					o&&(n.splice(t--,1),e=i(i.s=r[0]))
				}
				return e
			}var o={},s={app:0},n=[];
			function i(t)
			{
				if(o[t])return o[t].exports;
				var r=o[t]=
				{
					i:t,l:!1,exports:{}
				};
			return e[t].call(r.exports,r,r.exports,i),r.l=!0,r.exports
			}
			i.m=e,i.c=o,i.d=function(e,t,r)
			{
				i.o(e,t)||Object.defineProperty(e,t,
				{
					enumerable:!0,get:r
				})
			},i.r=function(e)
			{
				"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
				Object.defineProperty(e,"__esModule",{value:!0})
			},
			i.t=function(e,t)
			{
				if(1&t&&(e=i(e)),8&t)return e;
				if(4&t&&"object"===typeof e&&e&&e.__esModule)return e;
				var r=Object.create(null);
				if(i.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)i.d(r,o,function(t)
				{
					return e[t]}.bind(null,o));return r},i.n=function(e)
					{
						var t=e&&e.__esModule?function()
						{
							return e["default"]
						}:function()
						{
							return e
						};
						return i.d(t,"a",t),t},i.o=function(e,t)
						{
							return Object.prototype.hasOwnProperty.call(e,t)
						},i.p="/sita/";
						var c=window["webpackJsonp"]=window["webpackJsonp"]||[],l=c.push.bind(c);
						c.push=t,c=c.slice();
						for(var a=0;a<c.length;a++)t(c[a]);
						var u=l;n.push([0,"chunk-vendors"]),
						r()})({0:function(e,t,r){e.exports=r("56d7")},
						"034f":function(e,t,r)
						{
							"use strict";
							var o=r("64a9"),s=r.n(o);s.a
						},
						"0358":function(e,t,r){},
						"2f6b":function(e,t,r)
						{
							"use strict";
							var o=r("0358"),s=r.n(o);s.a
						},
						"56d7":function(e,t,r)
						{
							"use strict";
							r.r(t);
							var o=r("2b0e"),s=function()
							{
								var e=this,t=e.$createElement,r=e._self._c||t;
								return r("ColorTest")
							},
							n=[],
							i=function()
							{
								var e=this,
								t=e.$createElement,
								r=e._self._c||t;
								return r("div",{staticClass:"hello"},
								[e.started?e._e():r("div",{staticClass:"intro-msg"},
								[r("p",[e._v("\n  This pre-test will determine if you would be able to complete the study and takes about 5 minutes. You need to use the arrow keys on keyboard to complete the test. \n  Your task: If the two colored boxes have the same color, you press the left arrow and if the colors are different, you press the right arrow.\n")]),
								r("p",[e._v("\n        Press the Enter key to proceed.\n")])]),
								e.started?r("div",[r("div",{staticClass:"box-wrapper"},
								[r("div",{staticClass:"box",style:{"background-color":e.color1}}),
								r("div",{staticClass:"box",style:{"background-color":e.color2}})]),
								r("div",[e._v("\n        "+e._s(e.message)+"\n      ")]),
								e.linkDisplay?r("div",[r("a",
								{attrs:{
									href:"https://docs.google.com/forms/d/1mdHdTikRb2RYhtEAasmdvAo14pRe_ntEvATonN_xxQk/viewform?edit_requested=true"
									//document.getElementById('color-test-button').style.visibility = 'visible';
								}},
								[e._v("Click here to sign up.")])]):e._e()]):e._e()])},
								c=[];function l(e)
								{
									for(let t=e.length-1;t>0;t--)
									{
										const r=Math.floor(Math.random()*(t+1));
										[e[t],e[r]]=[e[r],e[t]]
									}
									return e
								}
								var a={name:"ColorTest",
								data:function()
								{
									return{
										started:!1,
										linkDisplay:!1,
										color1:"black",
										color2:"black",
										colors:["rgb(0,177,0)","rgb(255,78,255)","rgb(0,152,255)","rgb(255,1,0)"],
										colorIndices:[[0,0],[0,1],[0,2],[0,3],[1,1],[1,2],[1,3],[2,2],[2,3],[3,3],[0,0],[0,1],[0,2],[0,3],[1,1],[1,2],[1,3],[2,2],[2,3],[3,3],[0,0],[0,1],[0,2],[0,3],[1,1],[1,2],[1,3],[2,2],[2,3],[3,3],[0,0],[0,1],[0,2],[0,3],[1,1],[1,2],[1,3],[2,2],[2,3],[3,3],[1,0],[2,0],[2,1],[3,0],[3,1],[3,2],[1,0],[2,0],[2,1],[3,0],[3,1],[3,2],[1,0],[2,0],[2,1],[3,0],[3,1],[3,2],[1,0],[2,0],[2,1],[3,0],[3,1],[3,2]],currentIndex:0,
										results:[],
										message:"Press space bar when you are ready. (left arrow = YES | right arrow = NO)",
										selectionMode:!1}
								},
								mounted:function()
								{
									l(this.colorIndices),window.addEventListener("keydown",function(e){if(e.preventDefault(),13!==e.keyCode||this.started||(this.started=!0),this.started){if(32===e.keyCode&&!this.selectionMode)if(this.currentIndex===this.colorIndices.length)
									{
										let e=0;
										for(let t=0;t<this.results.length;t+=1)
											(this.results[t].colors[0]===this.results[t].colors[1]&&this.results[t].correctAnswer||this.results[t].colors[0]!==this.results[t].colors[1]&&!this.results[t].correctAnswer)&&(e+=1);
											this.message="You were correct in "+Math.round(100*e/this.currentIndex,1)+"% of cases. ",e/this.currentIndex<.9?this.message+="Sadly you cannot participate in the experiment. Please hand-in your pre-test survey and collect your reward. Please be careful to not disturb other test participants while you leave.":(this.message+="You are eligible to participate in the experiment.", document.getElementById('color-test-button').style.visibility = 'visible'),	//this.linkDisplay=!0),
											console.log(JSON.stringify(this.results))
									}
									else this.blinkImage(),this.message="Were the two colors the same? (left arrow = YES | right arrow = NO)",this.selectionMode=!0;!this.selectionMode||37!==e.keyCode&&39!==e.keyCode||(37===e.keyCode&&this.results.push({colors:this.colorIndices[this.currentIndex],correctAnswer:!0}),39===e.keyCode&&this.results.push({colors:this.colorIndices[this.currentIndex],correctAnswer:!1}),this.message="Press space bar when you are ready.",this.currentIndex+=1,this.selectionMode=!1)}}.bind(this))},methods:{blinkImage:function(){this.color1=this.colors[this.colorIndices[this.currentIndex][0]],this.color2=this.colors[this.colorIndices[this.currentIndex][1]],window.setTimeout(function(){this.color1="black",this.color2="black"}.bind(this),200)}}},u=a,h=(r("2f6b"),r("2877")),d=Object(h["a"])(u,i,c,!1,null,"2f7426ac",null),f=d.exports,p={name:"app",components:{ColorTest:f}},b=p,g=(r("034f"),Object(h["a"])(b,s,n,!1,null,null,null)),m=g.exports;o["a"].config.productionTip=!1,new o["a"]({render:function(e){return e(m)}}).$mount("#app")},"64a9":function(e,t,r){}});


document.getElementById('color-test-button').style.visibility = 'hidden';

//# sourceMappingURL=app.93a894ec.js.map
/*
<div class="info">
    <p>
        <button class="info-page-continue-button">
            Continue →
        </button>
    </p>
</div>
*/