Rails.application.routes.draw do

  root 'application#index'

  get 'barchart' => 'application#barchart'
  get 'boxchart' => 'application#boxchart'
  get 'ibqchart' => 'application#ibqchart'
  get 'ibcchart' => 'application#ibcchart'
  get 'eidchart' => 'application#eidchart'

  post 'answers' => 'answers#record'

end
